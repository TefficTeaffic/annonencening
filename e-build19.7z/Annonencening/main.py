import sys
import pygame as p

from resources.levels.level0 import level0
from resources.levels.level1 import level1
from resources.levels.level2 import level2
from resources.levels.level3 import level3

betaicon = p.image.load('resources/icons/betaicon.png')
player = p.image.load('resources/player/dora.png')
grpl = p.image.load('resources/icons/greyblock.png')
orpl = p.image.load('resources/icons/orangeblock.png')
lnpl = p.image.load('resources/icons/landblock.png')

pl_w = 50  # ширина платформы
pl_h = 50  # высота платформы
speed = 5  # скорость игрока
jump = 10  # длина прыжка игрока
gravity = 0.35  # сила гравитации
clock = p.time.Clock()  # механизм покадровой анимации

p_x = 450  # (активная) х игрока
p_y = 450  # (активная) у игрока
ground_ch = False  # (активная) проверка на касание земли

p.init()

screen = p.display.set_mode((1000, 600))
p.display.set_caption('Annonencening - Closed Beta (0.1 build)')
p.display.set_icon(betaicon)


def draw():
    screen.fill((153, 247, 247))


def leveldraw():
    level = level0
    x = y = 0

    for row in level:
        for col in row:

            if col == ".":
                screen.blit(grpl, (x, y))
            if col == "-":
                screen.blit(orpl, (x, y))
            if col == "=":
                screen.blit(lnpl, (x, y))

            x += pl_w
        y += pl_h
        x = 0


run = True
while run:
    for e in p.event.get():
        if e.type == p.QUIT:
            run = False

    if not ground_ch:
        p_y += gravity

    keys = p.key.get_pressed()

    if keys[p.K_w]:
        if ground_ch:
            p_y -= jump

    elif keys[p.K_a]:
        p_x -= speed
    elif keys[p.K_d]:
        p_x += speed
    elif keys[p.K_0]:
        level = level0
    elif keys[p.K_1]:
        level = level1
    elif keys[p.K_2]:
        level = level2

    draw()
    leveldraw()
    screen.blit(player, (p_x, p_y))
    p.display.update()
    clock.tick(60)

p.quit()
sys.exit()
