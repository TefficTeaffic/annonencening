import pygame as p
from pygame import *
import sys
from resources.levels.level1 import level1

betaicon = p.image.load('resources/icons/betaicon.png')
player = p.image.load('resources/player/dora.png')
PLATFORM_WIDTH = 50
PLATFORM_HEIGHT = 50
PLATFORM_COLOR = "#FF6262"
p_x = 450
p_y = 450
speed = 5
clock = p.time.Clock()


p.init()

screen = p.display.set_mode((1000, 600))
p.display.set_caption('Annonencening - Closed Beta (0.1 build)')
p.display.set_icon(betaicon)


def draw():
    screen.fill((153, 247, 247))


def leveldraw():
    level = level1
    x = y = 0 

    for row in level:  
        for col in row: 
            
            if col == "*":
                screen.blit(player, (x, y))
            if col == "-":
                screen.blit(betaicon, (x, y))

            x += PLATFORM_WIDTH
        y += PLATFORM_HEIGHT
        x = 0 


run = True
while run:
    for e in p.event.get():
        if e.type == p.QUIT:
            run = False

    keys = p.key.get_pressed()
    if keys[p.K_a]:
        p_x -= speed
    elif keys[p.K_d]:
        p_x += speed
    elif keys[p.K_s]:
        p_y -= speed
    elif keys[p.K_s]:
        p_y += speed

    draw()
    leveldraw()
    screen.blit(player, (p_x, p_y))
    p.display.update()
    clock.tick(60)

p.quit()
sys.exit()